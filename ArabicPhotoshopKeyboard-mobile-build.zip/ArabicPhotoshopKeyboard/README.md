# Arabic Photoshop Keyboard

Android IME keyboard inspired by the supplied screenshot. It keeps a normal Arabic keyboard layout, while **PS Mode** converts Arabic text into reversed Unicode Arabic Presentation Forms intended for legacy apps such as Photoshop versions that mishandle Arabic shaping.

Example:
- Input: `خالد`
- PS output: `ﺪﻟﺎﺧ`

## Build
Open the folder in Android Studio, allow Gradle sync, then Build > Build APK(s).

## Install / enable
1. Install the generated APK.
2. Open the app and tap **Enable keyboard**.
3. Select **Arabic Photoshop Keyboard** in Android's keyboard settings.
4. Switch to it from the keyboard picker.

## Important
Modern Photoshop versions may already support Arabic/RTL correctly. This keyboard targets workflows where the legacy presentation-form trick is required.
