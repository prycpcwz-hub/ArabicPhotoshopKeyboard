package com.bruce.arabicpskeyboard;

import java.util.HashMap;
import java.util.Map;

/** Converts Arabic letters to Unicode presentation forms, then reverses the sequence.
 *  This is the classic workaround used by some legacy applications that do not shape Arabic.
 */
public final class ArabicShaper {
    private static final class Forms {
        final char isolated, fin, initial, medial;
        Forms(char isolated, char fin, char initial, char medial) {
            this.isolated=isolated; this.fin=fin; this.initial=initial; this.medial=medial;
        }
    }
    private static final Map<Character, Forms> M = new HashMap<>();
    static {
        add('ء',0xFE80,0,0,0); add('آ',0xFE81,0xFE82,0,0); add('أ',0xFE83,0xFE84,0,0); add('ؤ',0xFE85,0xFE86,0,0);
        add('إ',0xFE87,0xFE88,0,0); add('ئ',0xFE89,0xFE8A,0xFE8B,0xFE8C); add('ا',0xFE8D,0xFE8E,0,0);
        add('ب',0xFE8F,0xFE90,0xFE91,0xFE92); add('ة',0xFE93,0xFE94,0,0); add('ت',0xFE95,0xFE96,0xFE97,0xFE98);
        add('ث',0xFE99,0xFE9A,0xFE9B,0xFE9C); add('ج',0xFE9D,0xFE9E,0xFE9F,0xFEA0); add('ح',0xFEA1,0xFEA2,0xFEA3,0xFEA4);
        add('خ',0xFEA5,0xFEA6,0xFEA7,0xFEA8); add('د',0xFEA9,0xFEAA,0,0); add('ذ',0xFEAB,0xFEAC,0,0);
        add('ر',0xFEAD,0xFEAE,0,0); add('ز',0xFEAF,0xFEB0,0,0); add('س',0xFEB1,0xFEB2,0xFEB3,0xFEB4);
        add('ش',0xFEB5,0xFEB6,0xFEB7,0xFEB8); add('ص',0xFEB9,0xFEBA,0xFEBB,0xFEBC); add('ض',0xFEBD,0xFEBE,0xFEBF,0xFEC0);
        add('ط',0xFEC1,0xFEC2,0xFEC3,0xFEC4); add('ظ',0xFEC5,0xFEC6,0xFEC7,0xFEC8); add('ع',0xFEC9,0xFECA,0xFECB,0xFECC);
        add('غ',0xFECD,0xFECE,0xFECF,0xFED0); add('ف',0xFED1,0xFED2,0xFED3,0xFED4); add('ق',0xFED5,0xFED6,0xFED7,0xFED8);
        add('ك',0xFED9,0xFEDA,0xFEDB,0xFEDC); add('ل',0xFEDD,0xFEDE,0xFEDF,0xFEE0); add('م',0xFEE1,0xFEE2,0xFEE3,0xFEE4);
        add('ن',0xFEE5,0xFEE6,0xFEE7,0xFEE8); add('ه',0xFEE9,0xFEEA,0xFEEB,0xFEEC); add('و',0xFEED,0xFEEE,0,0);
        add('ى',0xFEEF,0xFEF0,0,0); add('ي',0xFEF1,0xFEF2,0xFEF3,0xFEF4);
        add('پ',0xFB56,0xFB57,0xFB58,0xFB59); add('چ',0xFB7A,0xFB7B,0xFB7C,0xFB7D); add('ژ',0xFB8A,0xFB8B,0,0); add('گ',0xFB92,0xFB93,0xFB94,0xFB95);
    }
    private static void add(char c,int i,int f,int a,int m){M.put(c,new Forms((char)i,(char)f,(char)a,(char)m));}
    private static boolean connectsLeft(Forms f){ return f.initial!=0; }
    private static boolean connectsRight(Forms f){ return f.fin!=0; }

    public static String shapeAndReverse(String input) {
        if (input == null || input.isEmpty()) return input;
        StringBuilder shaped = new StringBuilder(input.length());
        char[] chars = input.toCharArray();
        for(int i=0;i<chars.length;i++) {
            char c=chars[i]; Forms f=M.get(c);
            if(f==null){ shaped.append(c); continue; }
            Forms prev=findPrev(chars,i); Forms next=findNext(chars,i);
            boolean joinPrev = prev!=null && prev.initial!=0 && f.fin!=0;
            boolean joinNext = next!=null && f.initial!=0 && next.fin!=0;
            char out;
            if(joinPrev && joinNext && f.medial!=0) out=f.medial;
            else if(joinPrev && f.fin!=0) out=f.fin;
            else if(joinNext && f.initial!=0) out=f.initial;
            else out=f.isolated;
            shaped.append(out);
        }
        return shaped.reverse().toString();
    }

    private static Forms findPrev(char[] a,int i){
        for(int j=i-1;j>=0;j--){ Forms f=M.get(a[j]); if(f!=null) return f; if(!Character.isWhitespace(a[j])) return null; }
        return null;
    }
    private static Forms findNext(char[] a,int i){
        for(int j=i+1;j<a.length;j++){ Forms f=M.get(a[j]); if(f!=null) return f; if(!Character.isWhitespace(a[j])) return null; }
        return null;
    }
}
