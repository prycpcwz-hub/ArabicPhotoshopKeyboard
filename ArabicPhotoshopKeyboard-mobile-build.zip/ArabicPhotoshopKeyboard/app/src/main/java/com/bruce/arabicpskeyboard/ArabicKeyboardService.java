package com.bruce.arabicpskeyboard;

import android.inputmethodservice.InputMethodService;
import android.view.View;
import android.view.inputmethod.InputConnection;

public class ArabicKeyboardService extends InputMethodService {
    private StringBuilder raw=new StringBuilder(); private boolean psMode=true; private ArabicKeyboardView view;
    @Override public View onCreateInputView(){ view=new ArabicKeyboardView(this,new ArabicKeyboardView.Listener(){
        public void key(String s){ raw.append(s); refresh(); }
        public void backspace(){ if(raw.length()>0){raw.deleteCharAt(raw.length()-1);refresh();} else {InputConnection ic=getCurrentInputConnection();if(ic!=null)ic.deleteSurroundingText(1,0);} }
        public void enter(){commitRaw("\n");}
        public void space(){commitRaw(" ");}
        public void toggleMode(){psMode=!psMode; raw.setLength(0);view.setPsMode(psMode);}
    }); return view; }
    private void refresh(){InputConnection ic=getCurrentInputConnection();if(ic==null)return;String out=psMode?ArabicShaper.shapeAndReverse(raw.toString()):raw.toString();ic.setComposingText(out,1);}
    private void commitRaw(String sep){InputConnection ic=getCurrentInputConnection();if(ic==null)return;String out=psMode?ArabicShaper.shapeAndReverse(raw.toString()):raw.toString();ic.commitText(out+sep,1);raw.setLength(0);}
    @Override public void onStartInputView(android.view.inputmethod.EditorInfo info, boolean restarting){super.onStartInputView(info,restarting);raw.setLength(0);}
}
