package com.bruce.arabicpskeyboard;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

public class ArabicKeyboardView extends View {
    public interface Listener { void key(String s); void backspace(); void enter(); void space(); void toggleMode(); }
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); private Listener listener; private boolean psMode=true;
    private final String[][] rows={{"ض","ص","ث","ق","ف","غ","ع","ه","خ","ح","ج"},{"ش","س","ي","ب","ل","ا","ت","ن","م","ك","ط"},{"ئ","ء","ؤ","ر","ى","ة","و","ز","ظ","ذ","د"}};
    private final List<Key> keys=new ArrayList<>();
    private static class Key { RectF r; String label; int type; Key(RectF r,String l,int t){this.r=r;label=l;type=t;} }
    public ArabicKeyboardView(Context c, Listener l){super(c); listener=l; p.setTypeface(android.graphics.Typeface.create("sans",0)); setBackgroundColor(0xFF050607);}
    public void setPsMode(boolean on){psMode=on;invalidate();}
    protected void onDraw(Canvas c){super.onDraw(c); keys.clear(); float w=getWidth(), h=getHeight();
        p.setStyle(Paint.Style.FILL); p.setColor(0xFF17191C); c.drawRect(0,0,w,48,p);
        p.setColor(0xFF00BCD4); p.setTextSize(18); p.setTextAlign(Paint.Align.CENTER); c.drawText(psMode?"PS MODE • ﺧﺮﻭﺝ ﻣﻌﻜﻮﺱ":"NORMAL MODE",w/2,31,p);
        float top=52, gap=5, keyH=Math.min(72,(h-126)/3f); float keyW=(w-20-gap*10)/11f;
        for(int r=0;r<3;r++){ float y=top+r*(keyH+gap); for(int i=0;i<11;i++){ float x=10+i*(keyW+gap); addKey(c,new RectF(x,y,x+keyW,y+keyH),rows[r][10-i],0); }}
        float y=top+3*(keyH+gap); float bw=(w-20-gap*5)/6f;
        addKey(c,new RectF(10,y,10+bw,y+keyH),"@!",3); addKey(c,new RectF(10+bw+gap,y,10+2*bw+gap,y+keyH),"123",3);
        addKey(c,new RectF(10+2*(bw+gap),y,10+3*bw+2*gap,y+keyH),"،",3);
        addKey(c,new RectF(10+3*(bw+gap),y,10+4*bw+3*gap,y+keyH),"space",2);
        addKey(c,new RectF(10+4*(bw+gap),y,10+5*bw+4*gap,y+keyH),"⌫",1);
        addKey(c,new RectF(10+5*(bw+gap),y,10+6*bw+5*gap,y+keyH),"✓",4);
        p.setColor(0xFF00BCD4);p.setTextSize(13);p.setTextAlign(Paint.Align.CENTER);c.drawText("اضغط العنوان لتبديل الوضع",w/2,h-4,p);
    }
    private void addKey(Canvas c,RectF r,String s,int type){p.setColor(type==2?0xFF101214:0xFF202327); c.drawRoundRect(r,10,10,p); p.setColor(type==2?0xFF00BCD4:0xFFE7E7E7); p.setTextAlign(Paint.Align.CENTER);p.setTextSize(type==0?29:20); c.drawText(s,r.centerX(),r.centerY()- (p.getFontMetrics().ascent+p.getFontMetrics().descent)/2,p); keys.add(new Key(r,s,type));}
    public boolean onTouchEvent(MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_UP)return true;float x=e.getX(),y=e.getY();
        if(y<48){listener.toggleMode();return true;} for(Key k:keys) if(k.r.contains(x,y)){if(k.type==0)listener.key(k.label);else if(k.type==1)listener.backspace();else if(k.type==2)listener.space();else if(k.type==4)listener.enter();return true;} return true;
    }
}
