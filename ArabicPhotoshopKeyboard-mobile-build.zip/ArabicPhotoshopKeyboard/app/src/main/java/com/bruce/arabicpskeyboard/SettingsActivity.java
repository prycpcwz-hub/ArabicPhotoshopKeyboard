package com.bruce.arabicpskeyboard;

import android.app.Activity;import android.os.Bundle;import android.content.Intent;import android.graphics.Color;import android.graphics.Typeface;import android.provider.Settings;import android.view.Gravity;import android.widget.*;

public class SettingsActivity extends Activity{
 @Override public void onCreate(Bundle b){super.onCreate(b); LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(28,40,28,28);root.setGravity(Gravity.CENTER_HORIZONTAL);root.setBackgroundColor(Color.BLACK);
  TextView title=new TextView(this);title.setText("Arabic Photoshop Keyboard");title.setTextColor(Color.WHITE);title.setTextSize(25);title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);root.addView(title,new LinearLayout.LayoutParams(-1,70));
  TextView info=new TextView(this);info.setText("كيبورد عربي عادي بنفس التخطيط، مع وضع PS يحوّل النص إلى الصيغة المناسبة للتطبيقات القديمة مثل Photoshop.\n\nمثال: خالد  →  ﺪﻟﺎﺧ");info.setTextColor(0xFFE0E0E0);info.setTextSize(18);info.setGravity(Gravity.CENTER);root.addView(info,new LinearLayout.LayoutParams(-1,0,1));
  Button enable=new Button(this);enable.setText("Enable keyboard");enable.setOnClickListener(v->{startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS));});root.addView(enable,new LinearLayout.LayoutParams(-1,60));
  setContentView(root);
 }
}
