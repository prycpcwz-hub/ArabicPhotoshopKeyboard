# بناء APK من الهاتف فقط

1. أنشئ مستودعًا جديدًا على GitHub.
2. ارفع كل ملفات هذا المجلد إلى المستودع.
3. افتح تبويب **Actions** ثم اختر **Build APK** واضغط **Run workflow**.
4. بعد انتهاء البناء، افتح التشغيل الناجح ثم قسم **Artifacts**.
5. حمّل `ArabicPhotoshopKeyboard-debug` على هاتفك وفك الضغط لتحصل على APK.
6. ثبّت APK، ثم من إعدادات Android > لوحة المفاتيح فعّل **Arabic Photoshop Keyboard** واختره.

ملاحظة: وضع PS MODE يحول الحروف العربية إلى Unicode Presentation Forms ويعكس ترتيبها لتناسب البرامج القديمة التي لا تقوم بتشكيل العربية.
